# Independent compact observation runtime review

Reviewed new runtime collector, immutable output writer, command entry point and pure replay code. No production files edited by this reviewer.

## Reproduced findings and disposition

1. P2: outer duplicate JSON keys were accepted by `json.Decoder`. A successful connected observation amended to `"outcome":"unavailable","outcome":"observed"` replayed as observed. Private Go overlay test failed before fix (`red.log`). The author now requires exact immutable writer serialization before replay (`compact_observation.go:176-180`), rejecting duplicate keys, case aliases and normalization. Same independent overlay is green (`green.log`).
2. P2: replay permitted each configuration body up to 4MiB with no aggregate bound, whereas capture permits 1MiB each/4MiB total. A >1MiB whitespace-padded valid packs body could replay though capture would refuse it. Same RED/GREEN evidence above. Author now shares one bound validator (`compact_observation.go:138-149`) across capture and replay.

## Checks with no further confirmed blocker

Verified exact trusted kit/installation/target-origin comparison; six reads before and after the one scoped evidence GET; running owner and handoff readiness, disabled production/legacy dispatch; stable epoch/revision/consumer manifest; full before/evidence/after chronology; failure observations rejected by pure replay; original response bytes preserved via base64; no raw non-200 error body or API key in terminal output; exclusive 0600 staging and nonreplacing hard-link publication; shutdown cancellation joins observation publication before runtime close returns.

Independent recheck ran the private two-counterexample overlay alongside all `TestCompactObservation` tests, passing. This is local authenticated HTTPS fixture evidence and replay validation, not real source-ingest coverage, pattern UAT, load/outage acceptance or a signature over artifacts. The new outer artifact intentionally rejects reformatting/normalization; body bytes are preserved exactly inside it.
