package runtime
import("bytes";"context";"encoding/json";"os";"path/filepath";"testing")
func TestReviewCompactReplayRejectsAmbiguousOrUncapturableArtifact(t *testing.T){
 app,kit,original,target,_,_:=compactObservationPeer(t,"");path:=filepath.Join(t.TempDir(),"evidence.json");if _,err:=app.ObserveCompact(context.Background(),kit,original,target,path);err!=nil{t.Fatal(err)};raw,_:=os.ReadFile(path)
 t.Run("duplicate-outcome",func(t *testing.T){bad:=bytes.Replace(raw,[]byte(`"outcome":"observed"`),[]byte(`"outcome":"unavailable","outcome":"observed"`),1);if bytes.Equal(raw,bad){t.Fatal("probe replacement missed")};if err:=ValidateCompactObservation(bad,kit,original);err==nil{t.Fatal("ambiguous failure then success accepted")}})
 t.Run("impossible-capture-body",func(t *testing.T){var report CompactObservationReport;if err:=json.Unmarshal(raw,&report);err!=nil{t.Fatal(err)};report.Before.Bodies["packs"]=append(bytes.Repeat([]byte(" "),(1<<20)+1),report.Before.Bodies["packs"]...);bad,_:=json.Marshal(report);if err:=ValidateCompactObservation(bad,kit,original);err==nil{t.Fatal("body larger than capture's 1MiB bound replayed")}})
}
