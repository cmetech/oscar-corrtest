# Current-runtime observer extension

A normal Correlator restart or compact commissioning changes runtime load timestamps even when the installed rule and pack are unchanged. The immutable installed-run preflight correctly refused those timestamps, but that strict contract prevented a read-only compact observation after restart.

The explicit `ReadCurrentRuntime` method uses the same six authenticated GETs and existing configuration/rule/runtime validators. Only `loaded_at` and `last_attempt_ms` are derived from the last runtime response. The pure `CurrentInstalledRuntimeBinding` helper verifies original expectations and all six bodies before returning a detached binding. Observer postflight must use existing strict `Read` with that first current binding; this rejects a second restart/change during the observation. Original `Read` and original pure installed-run validation retain their strict installation-time contract.

`current-runtime-red.log` records initial missing API failures. `current-runtime-green.log` passes new opt-in tests and legacy installed-pack tests. `current-runtime-race.log` passes the same focused group under the race detector. Cases include unchanged restarted rules, original input immutability, exact six requests, invalid/missing/duplicate/unsafe timestamps, changed rules/mappings/load identity, altered loaded rule IDs, enabled dispatch/authority, unavailable dependencies, rejected/unloaded rules, and changed postflight runtime.

Independent review and collector integration are owned by separate agents. This adapter change does not authorize compact admission, mutate service state or prove source coverage/UAT.
