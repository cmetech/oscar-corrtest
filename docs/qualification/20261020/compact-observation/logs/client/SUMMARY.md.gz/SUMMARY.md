# Compact evidence CorrTest client qualification

The adapter is connected to the sibling-owned `test-pack observe-compact` runtime.
This record covers the client and shared opt-in canonical codec, not live UAT acceptance.

## Tests and failures retained

- `red-01.log`: intended initial missing API/codec compile failures, before implementation.
- `green-01.log`: initial focused client/canonical tests passed.
- `red-02.log`: five contradictory projected-state regressions failed before stage consistency checks: receipt/work slot mismatch, inactive physically accepted incident, impossible sender attempt count, accepted receipt labelled pending, and early-stage reason with later ancestry.
- `green-02.log`: complete oscar + testpack packages passed after those checks.
- `full-01.log`: `go test ./... -count=1` passed all packages; slowest runner package 86.937s. This run preceded the atomic-counter-only test correction below.
- `race-01.log`: race detector caught the test HTTP request counter, read during canceled request cleanup. No production race reported.
- `race-02.log`: focused client/canonical race run passed after test counters became atomic.

## Evidence boundaries

Two original backend goldens are copied without mutation. A Python-generated synthetic Unicode/int64 fixture independently verifies canonical digest compatibility (HTML, U+2028/U+2029, emoji and signed int64 maximum). It is codec evidence, not a database observation.

Real local HTTPS test servers verify the exact public GET, operator CA validation, missing CA rejection, no redirect/retry/internal-service authority, identity content encoding, compressed refusal, declared and chunked body limits, cancellation, and preservation of bounded malformed 200 bytes. Non-200 response bodies are discarded and errors are fixed classifications.

Pure replay rejects duplicate keys, unsafe schema/extra fields, floats/overflow/unpaired Unicode, scope or revision mismatch, incomplete inventory, ordinal gaps, invalid counts, changed digests and contradictory physical/pending states. Healthy zero inventory and five legitimate pending stages remain distinct. A returned physical flag depends on authenticated backend chain validation; the client cannot reconstruct private source records omitted from the projection. The digest is not a signature.

The observer is read-only, supports only open compact Flood scopes, and keeps a stricter 4 MiB body bound than the backend's 8 MiB allowance. It has a 10-second request deadline. Observation timestamps are recorded and checked for local ordering, not treated as a cross-server freshness lease. No full-cohort source publication, load capacity, network outage recovery, or live Beast UAT claim follows from these tests. No Docker containers/images/volumes were created. No commit made by this agent.
